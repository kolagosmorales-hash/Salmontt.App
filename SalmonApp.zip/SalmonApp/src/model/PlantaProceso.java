package model;

public class PlantaProceso extends UnidadOperativa {

    private int id;
    private int capacidadProceso;
    private int toneladasProduccion;

    public PlantaProceso(int id, String nombre, String comuna, int capacidadProceso, int toneladasProduccion) {
        super(nombre, comuna);
        this.id = id;
        this.capacidadProceso = capacidadProceso;
        this.toneladasProduccion = toneladasProduccion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCapacidadProceso() {
        return capacidadProceso;
    }

    public void setCapacidadProceso(int capacidadProceso) {
        this.capacidadProceso = capacidadProceso;
    }

    public int getToneladasProduccion() {
        return toneladasProduccion;
    }

    public void setToneladasProduccion(int toneladasProduccion) {
        this.toneladasProduccion = toneladasProduccion;
    }

    @Override
    public String toString() {
        return String.format(
                "PlantaProceso{id=%d, nombre='%s', comuna='%s', capacidadProceso=%d, toneladasProduccion=%d}",
                id, getNombre(), getComuna(), capacidadProceso, toneladasProduccion
        );
    }
}