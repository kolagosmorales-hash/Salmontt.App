package model;

public class CentroCultivo extends UnidadOperativa {

    private int id;
    private int capacidadToneladas;
    private Estado estado;

    public enum Estado {
        OPERATIVO, MANTENCION, CERRADO
    }

    public CentroCultivo(int id, String nombre, String comuna, int capacidadToneladas, Estado estado) {
        super(nombre, comuna);
        this.id = id;
        this.capacidadToneladas = capacidadToneladas;
        this.estado = estado;
    }

    public int getId() { return id; }
    public int getCapacidadToneladas() { return capacidadToneladas; }
    public Estado getEstado() { return estado; }

    @Override
    public String toString() {
        return String.format("CentroCultivo{id=%d, nombre='%s', comuna='%s', capacidad=%d, estado=%s}",
                id, getNombre(), getComuna(), capacidadToneladas, estado);
    }
}