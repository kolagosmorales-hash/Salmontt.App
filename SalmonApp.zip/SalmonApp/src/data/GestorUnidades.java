package data;

import model.UnidadOperativa;
import model.PlantaProceso;
import service.CentroService;

import java.util.ArrayList;
import java.util.List;

public class GestorUnidades {

    public List<UnidadOperativa> crearUnidadesDePrueba() {
        List<UnidadOperativa> unidades = new ArrayList<>();
        
        CentroService cs = new CentroService();
        cs.cargarDesdeArchivo("data/centros.txt");
        unidades.addAll(cs.getCentros());

        unidades.add(new PlantaProceso(100, "Planta Sur", "Puerto Montt", 1200, 20000));
        unidades.add(new PlantaProceso(101, "Planta Norte", "Quellon", 900, 15000));

        return unidades;
    }
}