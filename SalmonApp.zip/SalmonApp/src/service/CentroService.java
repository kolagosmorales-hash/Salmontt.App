package service;

import model.CentroCultivo;
import model.CentroCultivo.Estado;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;

public class CentroService {

    private List<CentroCultivo> centros = new ArrayList<>();

    public void cargarDesdeArchivo(String ruta) {
        Path p = Paths.get(System.getProperty("user.dir"), ruta);
        try (BufferedReader br = Files.newBufferedReader(p)) {
            String linea;
            while ((linea = br.readLine()) != null) {
                procesarLinea(linea);
            }
            System.out.println("Carga completa. Total centros: " + centros.size());
        } catch (IOException e) {
            System.out.println("Error leyendo archivo: " + e.getMessage());
        }
    }

    private void procesarLinea(String l) {
        try {
            String[] p = l.split(";");
            int id = Integer.parseInt(p[0]);
            String nombre = p[1];
            String comuna = p[2];
            int capacidad = Integer.parseInt(p[3]);
            Estado estado = Estado.valueOf(p[4].toUpperCase());

            centros.add(new CentroCultivo(id, nombre, comuna, capacidad, estado));

        } catch (Exception e) {
            System.out.println("Línea erronea (omitida): " + l);
        }
    }

    public List<CentroCultivo> getCentros() {
        return centros;
    }
}