package ui;

import data.GestorUnidades;
import model.UnidadOperativa;
import model.CentroCultivo;
import model.PlantaProceso;

import java.util.List;

public class Main {

    public static void main(String[] args) {
        GestorUnidades gestor = new GestorUnidades();
        List<UnidadOperativa> unidades = gestor.crearUnidadesDePrueba();

        System.out.println("\n--- UNIDADES OPERATIVAS (DETALLE) ---\n");
        unidades.forEach(Main::imprimirDetalle);
    }

    private static void imprimirDetalle(UnidadOperativa u) {
        System.out.println("--------------------------------------------------");
        if (u instanceof CentroCultivo) {
            CentroCultivo c = (CentroCultivo) u;
            System.out.println("Tipo: Centro de Cultivo");
            System.out.println("ID   : " + c.getId());
            System.out.println("Nombre: " + c.getNombre());
            System.out.println("Comuna: " + c.getComuna());
            System.out.println("Capacidad (ton): " + c.getCapacidadToneladas());
            System.out.println("Estado: " + c.getEstado());
        } else if (u instanceof PlantaProceso) {
            PlantaProceso p = (PlantaProceso) u;
            System.out.println("Tipo: Planta de Proceso");
            System.out.println("ID   : " + p.getId());
            System.out.println("Nombre: " + p.getNombre());
            System.out.println("Comuna: " + p.getComuna());
            System.out.println("Capacidad proceso: " + p.getCapacidadProceso());
            System.out.println("Toneladas produccion: " + p.getToneladasProduccion());
        } else {
            System.out.println(u.toString());
        }
        System.out.println("--------------------------------------------------\n");
    }
}